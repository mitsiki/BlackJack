package Blackjack.Exceptions;

/**
 * Thrown when the starting size of a hand is less than 1.
 */
public class InvalidHandSizeException extends RuntimeException {
}
