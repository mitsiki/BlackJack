package Blackjack.Exceptions;

/**
 * Thrown when a bet is entered that isn't more than 0.
 */
public class InvalidBetException extends RuntimeException {
}
