package Blackjack.Exceptions;

/**
 * Thrown when a hand is bigger than the deck being drawn from.
 */
public class HandBiggerThanDeckException extends RuntimeException {
}
