package Blackjack.Exceptions;

/**
 * Thrown when a hand of cards is full and more is trying to be added.
 */
public class HandFullException extends RuntimeException {
}
