package Blackjack.Exceptions;

/**
 * Thrown when a bet exceeds amount of money available.
 */
public class BetTooBigException extends RuntimeException {
}
